public class User {
    public String name, password;

}
